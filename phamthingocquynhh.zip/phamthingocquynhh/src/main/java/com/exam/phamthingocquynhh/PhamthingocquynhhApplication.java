package com.exam.phamthingocquynhh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhamthingocquynhhApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhamthingocquynhhApplication.class, args);
    }

}
